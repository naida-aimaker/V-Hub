from typing import Annotated, Optional

from flet.controls.base_control import control
from flet.controls.control import Control
from flet.controls.control_event import ControlEventHandler
from flet.utils.validation import V

__all__ = ["SelectionArea"]


@control("SelectionArea")
class SelectionArea(Control):
    """
    Flet controls are not selectable by default. SelectionArea is used to enable \
    selection for its child control.
    """

    content: Annotated[
        Control,
        V.visible_control(),
    ]
    """
    The child control this selection area applies to.

    If you need to have multiple selectable controls, use container-like controls
    like :class:`~flet.Row` or :class:`~flet.Column`, which have a `controls` property
    for this purpose.

    Raises:
        ValueError: If :attr:`content` is not visible.
    """

    on_change: Optional[ControlEventHandler["SelectionArea"]] = None
    """
    Called when the selected content changes.
    """
